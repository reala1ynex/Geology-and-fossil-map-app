$ErrorActionPreference = 'Stop'

$repoUrl = 'https://github.com/reala1ynex/Geology-and-fossil-map-app.git'
$bundleName = 'StrataScoutNative-v2.1.0.gitbundle'
$targetName = 'Geology-and-fossil-map-app'

function Fail($message) {
    Write-Host "ERROR: $message" -ForegroundColor Red
    exit 1
}

if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
    Fail 'Git is not installed. Install Git for Windows from git-scm.com, then rerun this script.'
}

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$bundlePath = Join-Path $scriptDir $bundleName
if (-not (Test-Path $bundlePath)) {
    Fail "$bundleName must be in the same folder as this script."
}

$targetPath = Join-Path $scriptDir $targetName
if (Test-Path $targetPath) {
    Fail "$targetPath already exists. Rename or remove it, then rerun this script."
}

Write-Host 'Cloning the prepared StrataScout repository bundle...'
git clone $bundlePath $targetPath
Set-Location $targetPath

$existingOrigin = git remote get-url origin 2>$null
if ($LASTEXITCODE -eq 0) {
    git remote set-url origin $repoUrl
} else {
    git remote add origin $repoUrl
}

Write-Host 'Pushing to GitHub. A browser sign-in window may open.'
git push -u origin main

if ($LASTEXITCODE -ne 0) {
    Fail 'The push failed. Confirm you are signed into the reala1ynex GitHub account and rerun the script.'
}

Write-Host 'Published successfully:' -ForegroundColor Green
Write-Host 'https://github.com/reala1ynex/Geology-and-fossil-map-app'
