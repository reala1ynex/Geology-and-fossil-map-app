# Build an unsigned IPA with GitHub Actions

The included workflow builds the iPhone target on a GitHub-hosted Mac and packages an unsigned IPA. An unsigned IPA is not directly installable: it still must be signed for your Apple Account and device by Xcode or a compatible sideloading signer.

1. Push this repository to GitHub.
2. Open the repository's **Actions** tab.
3. Run **Build unsigned iPhone package**.
4. Download the `StrataScout-unsigned-ipa` artifact.
5. Sign/install it using your chosen iOS sideloading workflow.

Direct Xcode installation remains the simplest method when a Mac is available.
