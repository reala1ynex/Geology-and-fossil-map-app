# StrataScout Native

StrataScout is an MIT-licensed, offline-first iPhone field geology application. It is an original project and does not contain Backseat Geologist code, assets, branding, or interface elements.

## Runtime guarantees

- No network requests.
- No accounts, analytics, advertising, tracking, or cloud services.
- No generative AI.
- Rock photo matching is local visual similarity using Apple's on-device Vision feature-print API and bundled reference textures.
- The rock library, geology starter pack, field notes, GPX routes, and exports remain on the device unless the user explicitly shares a file.
- No CarPlay or Apple Watch targets or capabilities.

## Included features

- Fully offline custom geology map renderer.
- Generalized Berkshires starter geology pack.
- GeoJSON geology-pack import.
- GPX route import and route overlay.
- GPS and compass positioning.
- Spoken unit descriptions using the installed system voice.
- Automatic unit-change detection while walking or driving.
- Strike/dip field measurement helper using device motion and heading.
- Local rock-photo similarity matching with ranked alternatives.
- Offline wiki-style rock encyclopedia.
- Field notes with location, mapped unit, rock match, strike, and dip.
- GeoJSON and CSV export.

## Important scientific limits

The bundled Berkshires map is deliberately generalized and is not survey-grade. The photo matcher is an experimental field aid, not a petrographic identification. Confirm consequential identifications with mineral tests, a hand lens, regional maps, or a qualified geologist.

## Install on an iPhone with Xcode

1. Use a Mac with a current Xcode release.
2. Unzip the project and open `StrataScout.xcodeproj`.
3. Select the `StrataScout` target, open **Signing & Capabilities**, and choose your Apple ID team.
4. Change the bundle identifier if Xcode reports that it is already taken.
5. Connect the iPhone, trust the computer, choose the phone as the run destination, and press **Run**.
6. On the phone, approve Developer Mode or the developer profile when iOS requests it.

A paid Apple Developer account is not required for personal testing through Xcode. Free Personal Team signing may require periodic rebuilding and reinstallation; Xcode displays the current provisioning expiration.

## Optional unsigned IPA build

After pushing this project to GitHub, the included Actions workflow can compile an unsigned device IPA on a hosted Mac. The artifact still requires signing for your Apple Account and phone before installation. See `BUILD_UNSIGNED_IPA.md`.

## Offline data packs

The app accepts GeoJSON FeatureCollections containing Polygon or MultiPolygon features. Useful properties are:

```json
{
  "name": "Unit name",
  "age": "Ordovician",
  "lithology": "marble and dolostone",
  "description": "Plain-language description",
  "color": "#D9D4C5",
  "quality": "survey-grade or generalized",
  "source": "source and license"
}
```

Use `tools/normalize_geojson.py` to normalize third-party GeoJSON before importing it.

## Repository

Canonical repository: `reala1ynex/Geology-and-fossil-map-app`.
