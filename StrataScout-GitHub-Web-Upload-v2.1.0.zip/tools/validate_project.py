#!/usr/bin/env python3
from pathlib import Path
import json, plistlib, re, sys
root=Path(__file__).resolve().parents[1]
errors=[]
# JSON and plist validation
for p in root.rglob('*.json'):
    try: json.loads(p.read_text())
    except Exception as e: errors.append(f'{p}: {e}')
for p in [root/'StrataScout'/'Info.plist', root/'StrataScout'/'PrivacyInfo.xcprivacy']:
    try: plistlib.loads(p.read_bytes())
    except Exception as e: errors.append(f'{p}: {e}')
# Offline invariant
for p in root.rglob('*.swift'):
    text=p.read_text()
    if re.search(r'https?://|URLSession|NWConnection|WKWebView', text): errors.append(f'network-capable reference in {p}')
# Resources
reference_dir=root/'StrataScout'/'Resources'/'ReferenceTextures'
atlas=reference_dir/'ReferenceAtlas.jpg'
manifest=reference_dir/'ReferenceAtlas.json'
entries=[]
if not atlas.exists(): errors.append('missing ReferenceAtlas.jpg')
if not manifest.exists(): errors.append('missing ReferenceAtlas.json')
else:
    try: entries=json.loads(manifest.read_text()).get('entries', [])
    except Exception as e: errors.append(f'{manifest}: {e}')
if len(entries) < 30: errors.append(f'expected at least 30 atlas entries, found {len(entries)}')
if 'PBXProject' not in (root/'StrataScout.xcodeproj'/'project.pbxproj').read_text(): errors.append('invalid pbxproj marker')
if errors:
    print('\n'.join(errors)); sys.exit(1)
print(f'Validated project: {len(list(root.rglob("*.swift")))} Swift files, {len(entries)} atlas references, offline invariant passed.')
