#!/usr/bin/env python3
"""Normalize Polygon/MultiPolygon GeoJSON for StrataScout. No network access required."""
import argparse, json
from pathlib import Path

KEYS = {
    "name": ["name", "unit_name", "title", "map_unit"],
    "age": ["age", "interval", "period", "era"],
    "lithology": ["lithology", "lith", "rock_type"],
    "description": ["description", "descrip", "summary", "comments"],
    "color": ["color", "colour", "fill"],
    "quality": ["quality", "accuracy"],
    "source": ["source", "citation"]
}

def value(props, names, fallback):
    for name in names:
        if name in props and props[name] not in (None, ""): return str(props[name])
    return fallback

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('input'); ap.add_argument('output'); args=ap.parse_args()
    data=json.loads(Path(args.input).read_text())
    out=[]
    for i,f in enumerate(data.get('features', [])):
        g=f.get('geometry') or {}
        if g.get('type') not in ('Polygon','MultiPolygon'): continue
        p=f.get('properties') or {}
        props={k:value(p,v, {'name':f'Unit {i+1}','age':'Age not specified','lithology':'Lithology not specified','description':'','color':'#7A8578','quality':'Imported','source':'Imported GeoJSON'}[k]) for k,v in KEYS.items()}
        props['id']=str(p.get('id', f.get('id', f'feature-{i}')))
        out.append({'type':'Feature','properties':props,'geometry':g})
    Path(args.output).write_text(json.dumps({'type':'FeatureCollection','features':out},indent=2))
    print(f'Wrote {len(out)} polygon features to {args.output}')
if __name__=='__main__': main()
