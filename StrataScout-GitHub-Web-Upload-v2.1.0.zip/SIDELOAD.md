# Sideloading notes

This package contains source code, not a pre-signed IPA. An IPA cannot be produced generically because every install must be signed for a specific Apple developer team/device provisioning profile.

The lowest-friction route is Xcode personal-team signing. Keep all source and resource files inside the project directory, select your personal team, and run directly to the connected phone.

The app does not require iCloud, push notifications, background networking, HealthKit, CarPlay, WatchKit, or any paid entitlement.
