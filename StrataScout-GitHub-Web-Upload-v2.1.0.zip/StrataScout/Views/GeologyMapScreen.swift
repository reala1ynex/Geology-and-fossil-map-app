import SwiftUI
import UniformTypeIdentifiers
import CoreLocation

struct GeologyMapScreen: View {
    @EnvironmentObject private var location: LocationService
    @EnvironmentObject private var geology: GeologyPackStore
    @EnvironmentObject private var speech: SpeechService
    @State private var center = Coordinate(latitude: 42.32, longitude: -73.23)
    @State private var latitudeSpan = 0.82
    @State private var packImporter = false
    @State private var gpxImporter = false
    @State private var tracking = false
    @State private var lastAnnouncedUnitID: String?

    var body: some View {
        ZStack(alignment: .top) {
            OfflineGeologyMapView(center: $center, latitudeSpan: $latitudeSpan)
                .environmentObject(geology)
                .environmentObject(location)
                .ignoresSafeArea(edges: .bottom)

            HStack {
                StatusPill(text: geology.packName, systemImage: "externaldrive.fill")
                Spacer()
                if let accuracy = location.location?.horizontalAccuracy {
                    StatusPill(text: "±\(Int(accuracy)) m", systemImage: "location.fill")
                }
            }.padding(.horizontal).padding(.top, 8)
        }
        .navigationTitle("Offline Geology")
        .navigationBarTitleDisplayMode(.inline)
        .safeAreaInset(edge: .bottom) { unitCard }
        .toolbar {
            ToolbarItemGroup(placement: .topBarTrailing) {
                Menu {
                    Button("Import geology GeoJSON", systemImage: "square.and.arrow.down") { packImporter = true }
                    Button("Import GPX route", systemImage: "point.topleft.down.to.point.bottomright.curvepath") { gpxImporter = true }
                } label: { Image(systemName: "folder.badge.plus") }
                Button { locate() } label: { Image(systemName: "location") }
                Button { tracking.toggle() } label: { Image(systemName: tracking ? "speaker.wave.2.fill" : "speaker.slash") }
            }
        }
        .fileImporter(isPresented: $packImporter, allowedContentTypes: [.json, UTType(filenameExtension: "geojson")!]) { result in
            if case .success(let url) = result { geology.importPack(from: url) }
        }
        .fileImporter(isPresented: $gpxImporter, allowedContentTypes: [UTType(filenameExtension: "gpx") ?? .xml]) { result in
            if case .success(let url) = result { geology.importGPX(from: url) }
        }
        .onChange(of: location.location) { _, newLocation in
            guard let newLocation else { return }
            let c = Coordinate(latitude: newLocation.coordinate.latitude, longitude: newLocation.coordinate.longitude)
            let unit = geology.unit(at: c)
            if tracking, let unit, unit.id != lastAnnouncedUnitID {
                lastAnnouncedUnitID = unit.id
                speech.speak(unit: unit)
            }
        }
    }

    @ViewBuilder private var unitCard: some View {
        if let unit = geology.selectedUnit {
            VStack(alignment: .leading, spacing: 7) {
                HStack {
                    Circle().fill(unit.color).frame(width: 16, height: 16)
                    Text(unit.name).font(.headline)
                    Spacer()
                    Button { speech.speak(unit: unit) } label: { Image(systemName: "speaker.wave.2") }
                }
                Text("\(unit.age) · \(unit.lithology)").font(.subheadline).foregroundStyle(.secondary)
                Text(unit.description).font(.caption).lineLimit(3)
                Text("\(unit.quality) · \(unit.source)").font(.caption2).foregroundStyle(.secondary)
            }
            .padding().background(.regularMaterial)
        } else {
            Text("Tap the map to inspect a unit. The bundled pack is generalized, not survey-grade.")
                .font(.caption).padding().frame(maxWidth: .infinity).background(.regularMaterial)
        }
    }

    private func locate() {
        guard let l = location.location else { location.requestPermissionAndStart(); return }
        center = Coordinate(latitude: l.coordinate.latitude, longitude: l.coordinate.longitude)
        latitudeSpan = 0.12
        geology.select(at: center)
    }
}

struct OfflineGeologyMapView: View {
    @Binding var center: Coordinate
    @Binding var latitudeSpan: Double
    @EnvironmentObject private var geology: GeologyPackStore
    @EnvironmentObject private var location: LocationService
    @State private var dragOrigin: Coordinate?
    @State private var pinchOrigin: Double?

    var body: some View {
        GeometryReader { proxy in
            Canvas { context, size in
                drawBackground(context: &context, size: size)
                for unit in geology.units { draw(unit: unit, context: &context, size: size) }
                drawRoute(context: &context, size: size)
                if let location = location.location { drawLocation(location, context: &context, size: size) }
            }
            .contentShape(Rectangle())
            .gesture(dragGesture(size: proxy.size).simultaneously(with: magnificationGesture))
            .onTapGesture { point in
                let coordinate = coordinate(for: point, size: proxy.size)
                geology.select(at: coordinate)
            }
        }
        .background(Color(red: 0.08, green: 0.10, blue: 0.09))
    }

    private var longitudeSpan: Double { latitudeSpan * 1.35 }

    private func point(for c: Coordinate, size: CGSize) -> CGPoint {
        let x = ((c.longitude - (center.longitude - longitudeSpan / 2)) / longitudeSpan) * size.width
        let y = ((center.latitude + latitudeSpan / 2 - c.latitude) / latitudeSpan) * size.height
        return CGPoint(x: x, y: y)
    }

    private func coordinate(for p: CGPoint, size: CGSize) -> Coordinate {
        Coordinate(latitude: center.latitude + latitudeSpan / 2 - Double(p.y / size.height) * latitudeSpan,
                   longitude: center.longitude - longitudeSpan / 2 + Double(p.x / size.width) * longitudeSpan)
    }

    private func drawBackground(context: inout GraphicsContext, size: CGSize) {
        context.fill(Path(CGRect(origin: .zero, size: size)), with: .color(Color(red: 0.08, green: 0.10, blue: 0.09)))
        for i in 0...8 {
            let x = size.width * CGFloat(i) / 8
            var path = Path(); path.move(to: CGPoint(x: x, y: 0)); path.addLine(to: CGPoint(x: x, y: size.height))
            context.stroke(path, with: .color(.white.opacity(0.055)), lineWidth: 0.5)
        }
        for i in 0...12 {
            let y = size.height * CGFloat(i) / 12
            var path = Path(); path.move(to: CGPoint(x: 0, y: y)); path.addLine(to: CGPoint(x: size.width, y: y))
            context.stroke(path, with: .color(.white.opacity(0.055)), lineWidth: 0.5)
        }
    }

    private func draw(unit: GeologyUnit, context: inout GraphicsContext, size: CGSize) {
        for polygon in unit.polygons {
            guard let outer = polygon.first, let first = outer.first else { continue }
            var path = Path(); path.move(to: point(for: first, size: size))
            for c in outer.dropFirst() { path.addLine(to: point(for: c, size: size)) }
            path.closeSubpath()
            context.fill(path, with: .color(unit.color.opacity(0.72)))
            context.stroke(path, with: .color(.black.opacity(0.55)), lineWidth: geology.selectedUnit?.id == unit.id ? 3 : 1)
        }
        if latitudeSpan < 0.55 {
            let p = point(for: unit.centroid, size: size)
            context.draw(Text(unit.name).font(.caption2.bold()).foregroundStyle(.white).shadow(color: .black, radius: 2), at: p)
        }
    }

    private func drawRoute(context: inout GraphicsContext, size: CGSize) {
        guard let first = geology.route.first else { return }
        var path = Path(); path.move(to: point(for: first.coordinate, size: size))
        for routePoint in geology.route.dropFirst() { path.addLine(to: point(for: routePoint.coordinate, size: size)) }
        context.stroke(path, with: .color(.orange), style: StrokeStyle(lineWidth: 4, lineCap: .round, lineJoin: .round))
    }

    private func drawLocation(_ location: CLLocation, context: inout GraphicsContext, size: CGSize) {
        let p = point(for: Coordinate(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude), size: size)
        context.fill(Path(ellipseIn: CGRect(x: p.x-9, y: p.y-9, width: 18, height: 18)), with: .color(.white))
        context.fill(Path(ellipseIn: CGRect(x: p.x-6, y: p.y-6, width: 12, height: 12)), with: .color(.blue))
    }

    private func dragGesture(size: CGSize) -> some Gesture {
        DragGesture().onChanged { value in
            if dragOrigin == nil { dragOrigin = center }
            guard let origin = dragOrigin else { return }
            center = Coordinate(latitude: origin.latitude + Double(value.translation.height / size.height) * latitudeSpan,
                                longitude: origin.longitude - Double(value.translation.width / size.width) * longitudeSpan)
        }.onEnded { _ in dragOrigin = nil }
    }

    private var magnificationGesture: some Gesture {
        MagnificationGesture().onChanged { value in
            if pinchOrigin == nil { pinchOrigin = latitudeSpan }
            latitudeSpan = min(160, max(0.002, (pinchOrigin ?? latitudeSpan) / value))
        }.onEnded { _ in pinchOrigin = nil }
    }
}
