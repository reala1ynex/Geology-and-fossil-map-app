import SwiftUI
import PhotosUI
import UIKit

struct IdentifyView: View {
    @EnvironmentObject private var rocks: RockLibraryStore
    @State private var photoItem: PhotosPickerItem?
    @State private var image: UIImage?
    @State private var camera = false
    @State private var matches: [RockMatch] = []
    @State private var working = false
    @State private var errorMessage: String?
    private let matcher = VisualRockMatcher()

    var body: some View {
        ScrollView {
            VStack(spacing: 18) {
                imagePanel
                HStack {
                    PhotosPicker(selection: $photoItem, matching: .images) { Label("Choose Photo", systemImage: "photo") }
                        .buttonStyle(.borderedProminent)
                    Button { camera = true } label: { Label("Camera", systemImage: "camera") }
                        .buttonStyle(.bordered)
                }
                Text("Photos are processed on this phone. No image or result is uploaded.")
                    .font(.caption).foregroundStyle(.secondary)
                if working { ProgressView("Comparing bundled references…") }
                if let errorMessage { Text(errorMessage).foregroundStyle(.red).font(.caption) }
                matchList
                identificationKey
            }.padding()
        }
        .navigationTitle("Offline Rock Match")
        .sheet(isPresented: $camera) { CameraPicker(image: $image) }
        .onChange(of: photoItem) { _, item in load(item) }
        .onChange(of: image) { _, _ in analyze() }
    }

    private var imagePanel: some View {
        Group {
            if let image {
                Image(uiImage: image).resizable().scaledToFit().frame(maxHeight: 330).clipShape(RoundedRectangle(cornerRadius: 18))
            } else {
                RoundedRectangle(cornerRadius: 18).fill(.quaternary).frame(height: 240)
                    .overlay { Label("Photograph a clean, dry rock surface", systemImage: "camera.macro").foregroundStyle(.secondary) }
            }
        }
    }

    @ViewBuilder private var matchList: some View {
        if !matches.isEmpty {
            VStack(alignment: .leading, spacing: 10) {
                Text("Visual similarity ranking").font(.headline).frame(maxWidth: .infinity, alignment: .leading)
                ForEach(Array(matches.prefix(4).enumerated()), id: \.element.id) { rank, match in
                    if let article = rocks.article(id: match.rockID) {
                        NavigationLink(value: article) {
                            HStack {
                                Text("\(rank + 1)").font(.title3.monospacedDigit()).frame(width: 28)
                                VStack(alignment: .leading) {
                                    Text(article.name).font(.headline)
                                    Text(article.family).font(.caption).foregroundStyle(.secondary)
                                }
                                Spacer()
                                Text(match.similarity, format: .percent.precision(.fractionLength(0)))
                                    .font(.subheadline.monospacedDigit())
                            }.padding().background(.thinMaterial, in: RoundedRectangle(cornerRadius: 14))
                        }.buttonStyle(.plain)
                    }
                }
                Text("Similarity is not a calibrated identification probability. Use the field tests in each article before recording a result.")
                    .font(.caption).foregroundStyle(.secondary)
            }
            .navigationDestination(for: RockArticle.self) { RockArticleView(article: $0) }
        }
    }

    private var identificationKey: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Field check").font(.headline)
            Text("1. Inspect grain size and layering. 2. Test whether a steel nail scratches it. 3. Check whether it splits into sheets. 4. Use dilute acid only with proper field practice. 5. Compare against mapped regional geology.")
                .font(.subheadline)
        }.padding().background(.thinMaterial, in: RoundedRectangle(cornerRadius: 14))
    }

    private func load(_ item: PhotosPickerItem?) {
        guard let item else { return }
        Task {
            if let data = try? await item.loadTransferable(type: Data.self), let uiImage = UIImage(data: data) { image = uiImage }
        }
    }

    private func analyze() {
        guard let image else { return }
        working = true; errorMessage = nil; matches = []
        Task {
            do { matches = try await matcher.match(image: image) }
            catch { errorMessage = error.localizedDescription }
            working = false
        }
    }
}
