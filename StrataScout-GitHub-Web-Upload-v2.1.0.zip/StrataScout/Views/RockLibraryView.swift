import SwiftUI

struct RockLibraryView: View {
    @EnvironmentObject private var rocks: RockLibraryStore
    @State private var query = ""

    private var filtered: [RockArticle] {
        guard !query.isEmpty else { return rocks.articles }
        return rocks.articles.filter { $0.name.localizedCaseInsensitiveContains(query) || $0.family.localizedCaseInsensitiveContains(query) || $0.summary.localizedCaseInsensitiveContains(query) }
    }

    var body: some View {
        List(filtered) { article in
            NavigationLink(value: article) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(article.name).font(.headline)
                    Text(article.family).font(.caption).foregroundStyle(.secondary)
                    Text(article.summary).font(.caption).lineLimit(2)
                }.padding(.vertical, 4)
            }
        }
        .navigationTitle("Rock Library")
        .searchable(text: $query)
        .navigationDestination(for: RockArticle.self) { RockArticleView(article: $0) }
    }
}

struct RockArticleView: View {
    let article: RockArticle
    var body: some View {
        List {
            Section { Text(article.summary) }
            Section("Appearance") { ForEach(article.appearance, id: \.self) { Label($0, systemImage: "eye") } }
            Section("Field tests") { ForEach(article.fieldTests, id: \.self) { Label($0, systemImage: "checkmark.circle") } }
            Section("Formation") { Text(article.formation) }
            Section("Common confusions") { Text(article.commonConfusions) }
            Section("Limit") { Text(article.caution).foregroundStyle(.secondary) }
        }.navigationTitle(article.name)
    }
}
