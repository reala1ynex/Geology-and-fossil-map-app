import SwiftUI

struct RootView: View {
    var body: some View {
        TabView {
            NavigationStack { GeologyMapScreen() }
                .tabItem { Label("Map", systemImage: "map") }
            NavigationStack { IdentifyView() }
                .tabItem { Label("Identify", systemImage: "camera.macro") }
            NavigationStack { NotesView() }
                .tabItem { Label("Field Notes", systemImage: "square.and.pencil") }
            NavigationStack { RockLibraryView() }
                .tabItem { Label("Library", systemImage: "books.vertical") }
            NavigationStack { SettingsView() }
                .tabItem { Label("Settings", systemImage: "gearshape") }
        }
        .tint(.green)
    }
}
