import SwiftUI

struct NotesView: View {
    @EnvironmentObject private var notes: NoteStore
    @EnvironmentObject private var location: LocationService
    @EnvironmentObject private var geology: GeologyPackStore
    @EnvironmentObject private var sensors: SensorService
    @EnvironmentObject private var rocks: RockLibraryStore
    @State private var editing: FieldNote?
    @State private var exportURL: URL?

    var body: some View {
        List {
            if notes.notes.isEmpty {
                EmptyState(icon: "square.and.pencil", title: "No field notes", message: "Record a location, mapped unit, strike/dip estimate, and observations.")
                    .listRowBackground(Color.clear)
            }
            ForEach(notes.notes) { note in
                Button { editing = note } label: {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(note.title.isEmpty ? "Untitled field note" : note.title).font(.headline)
                        Text(note.createdAt, format: .dateTime.month().day().hour().minute()).font(.caption).foregroundStyle(.secondary)
                        if let unit = note.mappedUnit { Text(unit).font(.caption) }
                    }
                }.buttonStyle(.plain)
            }.onDelete(perform: notes.delete)
        }
        .navigationTitle("Field Notes")
        .toolbar {
            ToolbarItemGroup(placement: .topBarTrailing) {
                Menu {
                    Button("Export GeoJSON") { exportURL = try? ExportService.geoJSON(notes: notes.notes) }
                    Button("Export CSV") { exportURL = try? ExportService.csv(notes: notes.notes) }
                } label: { Image(systemName: "square.and.arrow.up") }
                Button { editing = newNote() } label: { Image(systemName: "plus") }
            }
        }
        .sheet(item: $editing) { note in NoteEditor(note: note) { notes.upsert($0) } }
        .sheet(isPresented: Binding(get: { exportURL != nil }, set: { if !$0 { exportURL = nil } })) {
            if let exportURL { ShareSheet(items: [exportURL]) }
        }
    }

    private func newNote() -> FieldNote {
        var note = FieldNote.blank()
        if let l = location.location {
            note.coordinate = Coordinate(latitude: l.coordinate.latitude, longitude: l.coordinate.longitude)
            note.mappedUnit = geology.unit(at: note.coordinate!)?.name
        }
        if let m = sensors.measurement(magneticHeading: location.heading?.trueHeading ?? location.heading?.magneticHeading) {
            note.strike = m.strike; note.dip = m.dip
        }
        return note
    }
}

struct NoteEditor: View {
    @Environment(\.dismiss) private var dismiss
    @State var note: FieldNote
    let save: (FieldNote) -> Void
    var body: some View {
        NavigationStack {
            Form {
                TextField("Title", text: $note.title)
                Section("Observations") { TextEditor(text: $note.body).frame(minHeight: 150) }
                Section("Location") {
                    LabeledContent("Latitude", value: note.coordinate.map { String(format: "%.6f", $0.latitude) } ?? "Not recorded")
                    LabeledContent("Longitude", value: note.coordinate.map { String(format: "%.6f", $0.longitude) } ?? "Not recorded")
                    LabeledContent("Mapped unit", value: note.mappedUnit ?? "None")
                }
                Section("Structure") {
                    TextField("Strike", text: Binding(get: { note.strike.map(String.init) ?? "" }, set: { note.strike = Int($0) })).keyboardType(.numberPad)
                    TextField("Dip", text: Binding(get: { note.dip.map(String.init) ?? "" }, set: { note.dip = Int($0) })).keyboardType(.numberPad)
                }
            }
            .navigationTitle("Field Note")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("Save") { save(note); dismiss() } }
            }
        }
    }
}

import UIKit
struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController { UIActivityViewController(activityItems: items, applicationActivities: nil) }
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}

