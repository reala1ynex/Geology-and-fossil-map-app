import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var location: LocationService
    @EnvironmentObject private var sensors: SensorService
    @EnvironmentObject private var geology: GeologyPackStore

    var body: some View {
        List {
            Section("Offline status") {
                Label("No network code is included", systemImage: "wifi.slash")
                Label("Rock library and references are bundled", systemImage: "internaldrive")
                Label("Notes are stored in the app Documents directory", systemImage: "lock.doc")
            }
            Section("Sensors") {
                LabeledContent("Location permission", value: String(describing: location.authorization))
                LabeledContent("Motion available", value: sensors.isAvailable ? "Yes" : "No")
                LabeledContent("Current dip estimate", value: "\(Int(sensors.dipDegrees.rounded()))°")
                if let heading = location.heading { LabeledContent("Heading", value: "\(Int(heading.magneticHeading.rounded()))°") }
            }
            Section("Data") {
                LabeledContent("Geology pack", value: geology.packName)
                LabeledContent("Map units", value: String(geology.units.count))
                LabeledContent("Route points", value: String(geology.route.count))
            }
            Section("Scientific use") {
                Text("The map renderer preserves imported geometry, but accuracy depends on the source pack. The built-in Berkshires pack is a generalized educational overview. The photo matcher ranks visual resemblance and cannot determine mineral chemistry, hardness, density, or acid reaction from an image.")
            }
            Section("Excluded by design") {
                Text("Cloud AI, accounts, analytics, advertising, CarPlay, Apple Watch, remote APIs, and automatic uploads are not present.")
            }
        }.navigationTitle("Settings")
    }
}
