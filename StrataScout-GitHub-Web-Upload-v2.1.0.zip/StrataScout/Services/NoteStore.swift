import Foundation
import SwiftUI

@MainActor
final class NoteStore: ObservableObject {
    @Published private(set) var notes: [FieldNote] = []
    @Published private(set) var lastError: String?

    private let fileURL: URL

    init() {
        let directory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        fileURL = directory.appendingPathComponent("stratascout-notes.json")
        load()
    }

    func upsert(_ note: FieldNote) {
        if let index = notes.firstIndex(where: { $0.id == note.id }) { notes[index] = note }
        else { notes.insert(note, at: 0) }
        notes.sort { $0.createdAt > $1.createdAt }
        save()
    }

    func delete(at offsets: IndexSet) {
        notes.remove(atOffsets: offsets)
        save()
    }

    private func load() {
        guard FileManager.default.fileExists(atPath: fileURL.path) else { return }
        do { notes = try JSONDecoder.strataScout.decode([FieldNote].self, from: Data(contentsOf: fileURL)) }
        catch { lastError = error.localizedDescription }
    }

    private func save() {
        do { try JSONEncoder.strataScout.encode(notes).write(to: fileURL, options: .atomic) }
        catch { lastError = error.localizedDescription }
    }
}

extension JSONEncoder {
    static var strataScout: JSONEncoder {
        let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys]; encoder.dateEncodingStrategy = .iso8601; return encoder
    }
}
extension JSONDecoder {
    static var strataScout: JSONDecoder {
        let decoder = JSONDecoder(); decoder.dateDecodingStrategy = .iso8601; return decoder
    }
}
