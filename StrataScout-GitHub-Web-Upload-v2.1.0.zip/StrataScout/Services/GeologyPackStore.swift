import Foundation
import Combine

@MainActor
final class GeologyPackStore: ObservableObject {
    @Published private(set) var units: [GeologyUnit] = []
    @Published var selectedUnit: GeologyUnit?
    @Published private(set) var route: [RoutePoint] = []
    @Published private(set) var packName = "No pack"
    @Published private(set) var lastError: String?

    func loadBundledPack() {
        guard let url = Bundle.main.url(forResource: "BerkshireStarter", withExtension: "geojson") else {
            lastError = "Bundled geology pack is missing."
            return
        }
        loadPack(url: url, name: "Berkshires starter")
    }

    func importPack(from url: URL) {
        let granted = url.startAccessingSecurityScopedResource()
        defer { if granted { url.stopAccessingSecurityScopedResource() } }
        loadPack(url: url, name: url.deletingPathExtension().lastPathComponent)
    }

    private func loadPack(url: URL, name: String) {
        do {
            let data = try Data(contentsOf: url)
            units = try GeoJSONDecoder.decodeUnits(data: data)
            packName = name
            selectedUnit = nil
            lastError = nil
        } catch {
            lastError = "Could not load geology pack: \(error.localizedDescription)"
        }
    }

    func importGPX(from url: URL) {
        let granted = url.startAccessingSecurityScopedResource()
        defer { if granted { url.stopAccessingSecurityScopedResource() } }
        do {
            route = try GPXParser.parse(data: Data(contentsOf: url))
            lastError = nil
        } catch {
            lastError = "Could not load GPX: \(error.localizedDescription)"
        }
    }

    func select(at coordinate: Coordinate) { selectedUnit = units.last(where: { $0.contains(coordinate) }) }
    func unit(at coordinate: Coordinate) -> GeologyUnit? { units.last(where: { $0.contains(coordinate) }) }
}

enum GeoJSONDecoder {
    enum DecodeError: Error { case invalidRoot, unsupportedGeometry }

    static func decodeUnits(data: Data) throws -> [GeologyUnit] {
        let object = try JSONSerialization.jsonObject(with: data)
        guard let root = object as? [String: Any], let features = root["features"] as? [[String: Any]] else { throw DecodeError.invalidRoot }
        return try features.enumerated().compactMap { index, feature in
            guard let geometry = feature["geometry"] as? [String: Any],
                  let type = geometry["type"] as? String,
                  let coordinates = geometry["coordinates"],
                  let properties = feature["properties"] as? [String: Any] else { return nil }
            let polygons: [[[Coordinate]]]
            if type == "Polygon" {
                polygons = [try polygon(coordinates)]
            } else if type == "MultiPolygon", let values = coordinates as? [Any] {
                polygons = try values.map(polygon)
            } else { return nil }
            let name = text(properties, ["name", "unit_name", "title"], fallback: "Unnamed unit")
            return GeologyUnit(
                id: text(properties, ["id", "map_id"], fallback: "feature-\(index)"),
                name: name,
                age: text(properties, ["age", "interval", "period"], fallback: "Age not specified"),
                lithology: text(properties, ["lithology", "lith", "rock_type"], fallback: "Lithology not specified"),
                description: text(properties, ["description", "descrip", "summary"], fallback: "No description supplied."),
                colorHex: text(properties, ["color", "colour", "fill"], fallback: "#7A8578"),
                quality: text(properties, ["quality", "accuracy"], fallback: "Imported"),
                source: text(properties, ["source", "citation"], fallback: "Imported GeoJSON"),
                polygons: polygons)
        }
    }

    private static func polygon(_ raw: Any) throws -> [[Coordinate]] {
        guard let rings = raw as? [Any] else { throw DecodeError.unsupportedGeometry }
        return try rings.map { ringRaw in
            guard let positions = ringRaw as? [Any] else { throw DecodeError.unsupportedGeometry }
            return try positions.map { positionRaw in
                guard let position = positionRaw as? [Any], position.count >= 2,
                      let lon = position[0] as? Double, let lat = position[1] as? Double else { throw DecodeError.unsupportedGeometry }
                return Coordinate(latitude: lat, longitude: lon)
            }
        }
    }

    private static func text(_ p: [String: Any], _ keys: [String], fallback: String) -> String {
        for key in keys {
            if let s = p[key] as? String, !s.isEmpty { return s }
            if let n = p[key] as? NSNumber { return n.stringValue }
        }
        return fallback
    }
}
