import Foundation

final class GPXParser: NSObject, XMLParserDelegate {
    enum ParseError: Error { case invalidDocument }
    private var points: [RoutePoint] = []
    private var currentCoordinate: Coordinate?
    private var currentElevation: Double?
    private var currentTimestamp: Date?
    private var currentText = ""

    static func parse(data: Data) throws -> [RoutePoint] {
        let delegate = GPXParser()
        let parser = XMLParser(data: data)
        parser.delegate = delegate
        guard parser.parse() else { throw parser.parserError ?? ParseError.invalidDocument }
        return delegate.points
    }

    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
        currentText = ""
        if elementName == "trkpt" || elementName == "rtept" || elementName == "wpt" {
            if let latText = attributeDict["lat"], let lonText = attributeDict["lon"], let lat = Double(latText), let lon = Double(lonText) {
                currentCoordinate = Coordinate(latitude: lat, longitude: lon)
                currentElevation = nil
                currentTimestamp = nil
            }
        }
    }

    func parser(_ parser: XMLParser, foundCharacters string: String) { currentText += string }

    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        let text = currentText.trimmingCharacters(in: .whitespacesAndNewlines)
        if elementName == "ele" { currentElevation = Double(text) }
        if elementName == "time" { currentTimestamp = ISO8601DateFormatter().date(from: text) }
        if (elementName == "trkpt" || elementName == "rtept" || elementName == "wpt"), let coordinate = currentCoordinate {
            points.append(RoutePoint(coordinate: coordinate, elevation: currentElevation, timestamp: currentTimestamp))
            currentCoordinate = nil
        }
    }
}
