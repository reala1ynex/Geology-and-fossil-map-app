import Foundation

@MainActor
enum ExportService {
    static func geoJSON(notes: [FieldNote]) throws -> URL {
        let features: [[String: Any]] = notes.compactMap { note in
            guard let c = note.coordinate else { return nil }
            return [
                "type": "Feature",
                "geometry": ["type": "Point", "coordinates": [c.longitude, c.latitude]],
                "properties": [
                    "id": note.id.uuidString,
                    "created_at": ISO8601DateFormatter().string(from: note.createdAt),
                    "title": note.title,
                    "notes": note.body,
                    "mapped_unit": note.mappedUnit ?? "",
                    "rock_id": note.rockID ?? "",
                    "strike": note.strike.map { $0 as Any } ?? NSNull(),
                    "dip": note.dip.map { $0 as Any } ?? NSNull()
                ]
            ]
        }
        let root: [String: Any] = ["type": "FeatureCollection", "features": features]
        let data = try JSONSerialization.data(withJSONObject: root, options: [.prettyPrinted, .sortedKeys])
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("StrataScout-Field-Notes.geojson")
        try data.write(to: url, options: .atomic)
        return url
    }

    static func csv(notes: [FieldNote]) throws -> URL {
        var rows = ["created_at,title,notes,latitude,longitude,mapped_unit,rock_id,strike,dip"]
        for note in notes {
            let values = [
                ISO8601DateFormatter().string(from: note.createdAt), note.title, note.body,
                note.coordinate.map { String($0.latitude) } ?? "", note.coordinate.map { String($0.longitude) } ?? "",
                note.mappedUnit ?? "", note.rockID ?? "", note.strike.map(String.init) ?? "", note.dip.map(String.init) ?? ""
            ].map(csvEscape)
            rows.append(values.joined(separator: ","))
        }
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("StrataScout-Field-Notes.csv")
        try rows.joined(separator: "\n").write(to: url, atomically: true, encoding: .utf8)
        return url
    }

    private static func csvEscape(_ value: String) -> String {
        "\"" + value.replacingOccurrences(of: "\"", with: "\"\"") + "\""
    }
}
