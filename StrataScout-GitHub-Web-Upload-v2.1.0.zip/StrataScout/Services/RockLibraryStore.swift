import Foundation
import Combine

@MainActor
final class RockLibraryStore: ObservableObject {
    @Published private(set) var articles: [RockArticle] = []
    @Published private(set) var lastError: String?

    func loadBundledLibrary() {
        guard let url = Bundle.main.url(forResource: "RockLibrary", withExtension: "json") else {
            lastError = "Bundled rock library is missing."
            return
        }
        do {
            articles = try JSONDecoder().decode([RockArticle].self, from: Data(contentsOf: url))
        } catch { lastError = error.localizedDescription }
    }

    func article(id: String) -> RockArticle? { articles.first { $0.id == id } }
}
