import Foundation
import CoreMotion
import Combine

@MainActor
final class SensorService: ObservableObject {
    @Published private(set) var dipDegrees: Double = 0
    @Published private(set) var rollDegrees: Double = 0
    @Published private(set) var pitchDegrees: Double = 0
    @Published private(set) var isAvailable = false

    private let motion = CMMotionManager()
    private let queue = OperationQueue()

    func start() {
        guard motion.isDeviceMotionAvailable else { return }
        isAvailable = true
        motion.deviceMotionUpdateInterval = 0.12
        motion.startDeviceMotionUpdates(to: queue) { [weak self] data, _ in
            guard let data else { return }
            let gravityZ = min(1, max(-1, abs(data.gravity.z)))
            let dip = acos(gravityZ) * 180 / .pi
            Task { @MainActor in
                self?.dipDegrees = dip
                self?.rollDegrees = data.attitude.roll * 180 / .pi
                self?.pitchDegrees = data.attitude.pitch * 180 / .pi
            }
        }
    }

    func stop() { motion.stopDeviceMotionUpdates() }

    func measurement(magneticHeading: Double?) -> (strike: Int, dip: Int)? {
        guard let heading = magneticHeading else { return nil }
        let dipDirection = Int(heading.rounded()) % 360
        let strike = (dipDirection + 90) % 180
        return (strike, Int(dipDegrees.rounded()))
    }
}
