import Foundation
import UIKit
import Vision

actor VisualRockMatcher {
    enum MatchError: LocalizedError {
        case invalidImage, noReferences
        var errorDescription: String? {
            switch self {
            case .invalidImage: "The selected image could not be analyzed."
            case .noReferences: "No bundled reference textures were found."
            }
        }
    }

    private struct AtlasManifest: Decodable {
        let image: String
        let entries: [AtlasEntry]
    }

    private struct AtlasEntry: Decodable {
        let rockID: String
        let name: String
        let x: Int
        let y: Int
        let width: Int
        let height: Int
    }

    func match(image: UIImage) throws -> [RockMatch] {
        guard let queryImage = image.normalizedCGImage else { throw MatchError.invalidImage }
        let query = try featurePrint(queryImage)
        let references = try loadReferences()

        var bestByRock: [String: Float] = [:]
        for reference in references {
            let observation = try featurePrint(reference.image)
            var distance: Float = 0
            try query.computeDistance(&distance, to: observation)
            bestByRock[reference.rockID] = min(bestByRock[reference.rockID] ?? .greatestFiniteMagnitude, distance)
        }

        return bestByRock.map { id, distance in
            let similarity = max(0, min(1, exp(-Double(distance) / 10.5)))
            return RockMatch(rockID: id, distance: distance, similarity: similarity)
        }.sorted { $0.distance < $1.distance }
    }

    private func loadReferences() throws -> [(rockID: String, image: CGImage)] {
        guard
            let manifestURL = Bundle.main.url(forResource: "ReferenceAtlas", withExtension: "json", subdirectory: "ReferenceTextures"),
            let manifest = try? JSONDecoder().decode(AtlasManifest.self, from: Data(contentsOf: manifestURL)),
            let imageName = manifest.image.split(separator: ".", maxSplits: 1).first.map(String.init),
            let imageExtension = manifest.image.split(separator: ".", maxSplits: 1).dropFirst().first.map(String.init),
            let atlasURL = Bundle.main.url(forResource: imageName, withExtension: imageExtension, subdirectory: "ReferenceTextures"),
            let atlas = UIImage(contentsOfFile: atlasURL.path)?.normalizedCGImage
        else { throw MatchError.noReferences }

        let scaleX = CGFloat(atlas.width) / CGFloat(max(1, manifest.entries.map { $0.x + $0.width }.max() ?? atlas.width))
        let scaleY = CGFloat(atlas.height) / CGFloat(max(1, manifest.entries.map { $0.y + $0.height }.max() ?? atlas.height))

        let references = manifest.entries.compactMap { entry -> (String, CGImage)? in
            let rect = CGRect(
                x: CGFloat(entry.x) * scaleX,
                y: CGFloat(entry.y) * scaleY,
                width: CGFloat(entry.width) * scaleX,
                height: CGFloat(entry.height) * scaleY
            ).integral
            guard let crop = atlas.cropping(to: rect) else { return nil }
            return (entry.rockID, crop)
        }
        guard !references.isEmpty else { throw MatchError.noReferences }
        return references
    }

    private func featurePrint(_ cgImage: CGImage) throws -> VNFeaturePrintObservation {
        let request = VNGenerateImageFeaturePrintRequest()
        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
        try handler.perform([request])
        guard let result = request.results?.first as? VNFeaturePrintObservation else { throw MatchError.invalidImage }
        return result
    }
}

private extension UIImage {
    var normalizedCGImage: CGImage? {
        if imageOrientation == .up, let cgImage { return cgImage }
        let renderer = UIGraphicsImageRenderer(size: size)
        return renderer.image { _ in draw(in: CGRect(origin: .zero, size: size)) }.cgImage
    }
}
