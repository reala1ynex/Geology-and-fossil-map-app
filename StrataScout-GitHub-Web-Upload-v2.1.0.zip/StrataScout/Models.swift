import Foundation
import CoreLocation
import SwiftUI

struct Coordinate: Codable, Hashable, Sendable {
    var latitude: Double
    var longitude: Double

    var clLocationCoordinate: CLLocationCoordinate2D {
        CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
    }
}

struct GeologyUnit: Identifiable, Codable, Hashable, Sendable {
    var id: String
    var name: String
    var age: String
    var lithology: String
    var description: String
    var colorHex: String
    var quality: String
    var source: String
    var polygons: [[[Coordinate]]]

    var color: Color { Color(hex: colorHex) }

    var centroid: Coordinate {
        let points = polygons.flatMap { $0.flatMap { $0 } }
        guard !points.isEmpty else { return Coordinate(latitude: 0, longitude: 0) }
        return Coordinate(latitude: points.map(\.latitude).reduce(0,+) / Double(points.count),
                          longitude: points.map(\.longitude).reduce(0,+) / Double(points.count))
    }

    func contains(_ point: Coordinate) -> Bool {
        polygons.contains { polygon in
            guard let outer = polygon.first, pointInRing(point, ring: outer) else { return false }
            for hole in polygon.dropFirst() where pointInRing(point, ring: hole) { return false }
            return true
        }
    }

    private func pointInRing(_ point: Coordinate, ring: [Coordinate]) -> Bool {
        guard ring.count > 2 else { return false }
        var inside = false
        var j = ring.count - 1
        for i in ring.indices {
            let xi = ring[i].longitude, yi = ring[i].latitude
            let xj = ring[j].longitude, yj = ring[j].latitude
            let intersects = ((yi > point.latitude) != (yj > point.latitude)) &&
                (point.longitude < (xj - xi) * (point.latitude - yi) / ((yj - yi) == 0 ? 1e-12 : (yj - yi)) + xi)
            if intersects { inside.toggle() }
            j = i
        }
        return inside
    }
}

struct RoutePoint: Codable, Hashable, Sendable {
    var coordinate: Coordinate
    var elevation: Double?
    var timestamp: Date?
}

struct RockArticle: Identifiable, Codable, Hashable, Sendable {
    var id: String
    var name: String
    var family: String
    var summary: String
    var appearance: [String]
    var fieldTests: [String]
    var formation: String
    var commonConfusions: String
    var caution: String
}

struct RockMatch: Identifiable, Hashable, Sendable {
    var id: String { rockID }
    var rockID: String
    var distance: Float
    var similarity: Double
}

struct FieldNote: Identifiable, Codable, Hashable, Sendable {
    var id: UUID
    var createdAt: Date
    var title: String
    var body: String
    var coordinate: Coordinate?
    var mappedUnit: String?
    var rockID: String?
    var strike: Int?
    var dip: Int?

    static func blank() -> FieldNote {
        FieldNote(id: UUID(), createdAt: .now, title: "", body: "", coordinate: nil,
                  mappedUnit: nil, rockID: nil, strike: nil, dip: nil)
    }
}

extension Color {
    init(hex: String) {
        let value = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: value).scanHexInt64(&int)
        let r, g, b: UInt64
        switch value.count {
        case 3: (r,g,b) = ((int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        default: (r,g,b) = (int >> 16, int >> 8 & 0xFF, int & 0xFF)
        }
        self.init(.sRGB, red: Double(r)/255, green: Double(g)/255, blue: Double(b)/255, opacity: 1)
    }
}
