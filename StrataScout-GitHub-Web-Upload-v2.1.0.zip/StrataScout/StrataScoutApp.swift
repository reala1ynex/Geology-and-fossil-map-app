import SwiftUI

@main
struct StrataScoutApp: App {
    @StateObject private var location = LocationService()
    @StateObject private var sensors = SensorService()
    @StateObject private var geology = GeologyPackStore()
    @StateObject private var rocks = RockLibraryStore()
    @StateObject private var notes = NoteStore()
    @StateObject private var speech = SpeechService()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(location)
                .environmentObject(sensors)
                .environmentObject(geology)
                .environmentObject(rocks)
                .environmentObject(notes)
                .environmentObject(speech)
                .task {
                    geology.loadBundledPack()
                    rocks.loadBundledLibrary()
                    location.requestPermissionAndStart()
                    sensors.start()
                }
        }
    }
}
